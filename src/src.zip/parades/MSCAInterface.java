package parades;

public interface MSCAInterface {
	public String lcs(char[] seqX, char[] seqY);
}
